library qr_code_scanner;

export 'src/mock_qr_view.dart'; // or whatever file contains QRView, QRViewController, etc.
