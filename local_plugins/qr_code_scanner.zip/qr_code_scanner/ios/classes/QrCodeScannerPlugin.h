#import <Flutter/Flutter.h>

@interface QrCodeScannerPlugin : NSObject<FlutterPlugin>
@end
