enum BiometricType {
  fingerprint,
  face,
  iris,
}
