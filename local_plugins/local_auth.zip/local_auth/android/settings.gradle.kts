rootProject.name = 'local_auth_android'
